Nature Communications submission package (single-file)
======================================================
MAIN FILE: main.tex   ← set this as the Overleaf "Main document"

Everything (preamble, body, figure floats) is inlined into main.tex —
there are NO \input files, so Overleaf cannot pick the wrong main file.
All Unicode is already substituted to LaTeX, so no special packages are
needed beyond the official sn-jnl class.

Build:  pdflatex main && bibtex main && pdflatex main && pdflatex main

Files
-----
main.tex            self-contained manuscript (sn-jnl / sn-nature style)
manuscript.pdf      pre-compiled 34-page PDF (reference)
sn-jnl.cls          official Springer Nature document class
sn-nature.bst       Nature Portfolio bibliography style
refs.bib            bibliography (24 entries)
fig1/17/22/26/29/30 .png   six main figures
COVER_LETTER.md, SUPPLEMENTARY.md, SUBMISSION_CHECKLIST.md

If uploading to Overleaf: upload the whole folder, then
Menu → Main document → main.tex, and Recompile.

Outstanding human items (SUBMISSION_CHECKLIST.md): affiliations,
corresponding email, funding, author contributions, acknowledgements,
suggested reviewers, copy-edit, Zenodo DOI.
