Nature Communications submission package
========================================
Build:  pdflatex main_sn && bibtex main_sn && pdflatex main_sn && pdflatex main_sn
Self-contained: compiles on any TeX Live / Overleaf with no extra packages
(all Unicode is substituted to LaTeX in body_sn.tex; \tightlist + calc
handled in the preamble of main_sn.tex).

manuscript.pdf  = pre-compiled 34-page manuscript (sn-jnl / sn-nature).
Outstanding human items: affiliations, corresponding email, funding,
author contributions, acknowledgements, suggested reviewers, copy-edit,
Zenodo DOI (see SUBMISSION_CHECKLIST.md).
