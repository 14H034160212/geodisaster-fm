Nature Communications submission package
========================================
Manuscript: "Cross-disaster mapping is largely a calibration problem,
not a representation problem: four labels recover 99% of the full-pool
oracle, regardless of how those labels are chosen"

Contents
--------
manuscript.pdf        Compiled manuscript (42 pp, sn-jnl / sn-nature style)
main_sn.tex           LaTeX source (Springer Nature sn-jnl class)
body_sn.tex           Manuscript body (\input by main_sn.tex)
figures_sn.tex        Figure float definitions + captions
sn-jnl.cls            Official Springer Nature document class
sn-nature.bst         Nature Portfolio bibliography style
refs.bib              Bibliography (24 entries)
fig1_h1_h2_concept.png ... fig30_backbone_ordering.png   Six main figures
COVER_LETTER.md       Cover letter to the editor
SUPPLEMENTARY.md      Supplementary information (within-event ablations)
SUBMISSION_CHECKLIST.md  Pre-submission checklist (remaining human items)

Build
-----
pdflatex main_sn && bibtex main_sn && pdflatex main_sn && pdflatex main_sn

Outstanding before submission (see SUBMISSION_CHECKLIST.md)
----------------------------------------------------------
Author affiliations, corresponding email, funding, author contributions,
acknowledgements, suggested reviewers, final copy-edit, Zenodo DOI.
