GeoDisaster-FM — Nature Communications submission package
=========================================================

ONE package, two uses:

1) Compile on Overleaf
   - New Project -> Upload Project -> this zip
   - Menu -> Compiler: pdfLaTeX
   - Recompile  ->  35-page PDF (verified 0 errors)

2) Submit to Nature
   - manuscript.pdf  : compiled manuscript (ready to upload)
   - main.tex        : single-file LaTeX source (sn-jnl class)
   - refs.bib        : bibliography
   - sn-jnl.cls, sn-nature.bst : official Springer Nature template
   - fig*.png         : 7 main figures (fig2 = system architecture)
   - COVER_LETTER.md  : cover letter
   - SUPPLEMENTARY.md : supplementary information

Still TODO before clicking submit (human-only):
   author affiliations, corresponding email, funding,
   author contributions, suggested reviewers.
