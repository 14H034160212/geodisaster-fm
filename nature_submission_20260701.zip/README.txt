GeoDisaster-FM — Nature Communications submission package
=========================================================

ONE package, two uses:

1) Compile on Overleaf
   - New Project -> Upload Project -> this zip
   - Menu -> Compiler: pdfLaTeX
   - Recompile  ->  35-page PDF (verified 0 errors)

2) Submit to Nature
   - manuscript.pdf  : compiled manuscript (figures inline near first
                       citation, in Fig. 1-7 order; all 24 bibliography
                       entries cited in text)
   - main.tex        : single-file LaTeX source (sn-jnl class)
   - refs.bib        : bibliography (24 entries, all cited)
   - sn-jnl.cls, sn-nature.bst : official Springer Nature template
   - fig*.png         : 7 main figures (fig2_system_architecture = Fig. 3,
                        the pipeline/system diagram)
   - COVER_LETTER.md  : cover letter
   - SUPPLEMENTARY.md : supplementary information

Still TODO before clicking submit (human-only):
   author affiliations, corresponding email, funding,
   author contributions, suggested reviewers.
