GeoDisaster-FM — Nature Communications submission package
=========================================================

1) Compile on Overleaf
   - Upload this zip as a project
   - Compiler: pdfLaTeX

2) Submit to Nature
   - manuscript.pdf, main.tex, refs.bib
   - sn-jnl.cls, sn-nature.bst
   - figure png files
   - COVER_LETTER.md, SUPPLEMENTARY.md
